Place ixgame-banner.png beside index.html/run_lapse.html in your repository. The workflow rebuilds a clean site from RAW engine files and iXGAME UI.
