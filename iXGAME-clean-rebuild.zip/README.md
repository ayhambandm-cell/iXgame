# iXGAME.io — Clean Rebuild

A clean static rebuild of the supplied iXGAME interface, prepared for GitHub Pages.

## Files
- `index.html` — responsive landing page and status/overlay UI.
- `assets/ixgame-banner.svg` — local banner artwork (no external image dependency).
- `assets/ixgame-mark.svg` — favicon.
- `.nojekyll` — tells GitHub Pages not to run Jekyll processing.
- `manifest.json` — simple project metadata.

## Publish on GitHub Pages
1. Download and extract this ZIP.
2. Upload the **contents** of this folder to the root of your GitHub repository (the `index.html` file must be at the root).
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
5. Wait for the Pages deployment to finish.

For the shortest free GitHub Pages URL, use a repository named `YOUR-USERNAME.github.io`. For a project repository named `iXgame`, the URL normally includes `/iXgame/`.

## Important
This package rebuilds the front-end interface only. The uploaded source referenced `run_lapse.html` and `run_poops.html`, but those execution files were not included in the supplied file. This rebuild intentionally does not pretend those missing modules exist or automatically redirect to them. Add only the actual files you intend to host after reviewing them.

The old `cache.appcache` manifest was removed because the original project used deprecated Application Cache behavior.
