# Firmware notes

The firmware matrix is a research index, not a compatibility guarantee.

- RawGame4's README describes Lapse and Poops project routes and publishes its own firmware/test notes.
- Its 10.01 entry is described as not hardware-tested.
- Do not extrapolate RawGame4's chain to 13.02–13.52.
- Raw13G is tracked as a separate project family; verify the exact repository revision and device notes.
- Never mix offsets, patch data, kernel structures or payload builds across firmware versions without explicit validation.

Record test results with console model, exact firmware, source commit, browser environment, date and observed result.
