const translations = {
en: {
"nav.home":"Dashboard","nav.firmware":"Firmware","nav.webkit":"WebKit","nav.payloads":"Payloads","nav.homebrew":"Homebrew","nav.tools":"Tools","nav.docs":"Docs",
"hero.eyebrow":"INDEPENDENT PLAYSTATION 4 PLATFORM","hero.title":"THE RAVEN<br><em>PROTOCOL.</em>","hero.desc":"A dark, independent hub for PS4 firmware research, WebKit projects, payload references and homebrew resources.","hero.primary":"EXPLORE FIRMWARE <b>↗</b>","hero.secondary":"READ DOCUMENTATION","hero.open":"OPEN ACCESS",
"stats.scope":"FIRMWARE RANGE","stats.scopeNote":"Target scope · compatibility varies","stats.modules":"PLATFORM MODULES","stats.modulesNote":"Independent sections","stats.access":"ACCESS MODEL","stats.accessNote":"No sign-in or subscriptions","stats.status":"PROJECT STATUS","stats.statusNote":"Community resources · verify first",
"sections.modules":"PLATFORM MODULES","sections.explore":"Explore the <em>system.</em>","sections.select":"SELECT A MODULE TO CONTINUE",
"cards.firmware":"Firmware Matrix","cards.firmwareDesc":"Version routes, source families and verification notes.","cards.webkit":"WebKit Lab","cards.webkitDesc":"Research projects, chain architecture and upstream references.","cards.payloads":"Payload Vault","cards.payloadsDesc":"Payload sources, metadata and local file inspection.","cards.homebrew":"Homebrew","cards.homebrewDesc":"Community applications and installation references.","cards.tools":"Tools & Utilities","cards.toolsDesc":"Local tools and developer utilities directory.","cards.docs":"Documentation","cards.docsDesc":"Guides, safety notes, credits and project policies.",
"feature.title":"Know the source.<br><em>Verify the build.</em>","feature.desc":"iXGAME separates original platform code from third-party projects. Every external payload must retain its own license and compatibility notes.","feature.cta":"PROJECT POLICY ↗"
},
ar: {
"nav.home":"الرئيسية","nav.firmware":"الفيرموير","nav.webkit":"WebKit","nav.payloads":"البايلودز","nav.homebrew":"هومبرو","nav.tools":"الأدوات","nav.docs":"التوثيق",
"hero.eyebrow":"منصة مستقلة لأجهزة PLAYSTATION 4","hero.title":"بروتوكول<br><em>الغُراب.</em>","hero.desc":"منصة تقنية مستقلة لأبحاث فيرموير PS4 ومشاريع WebKit ومراجع Payloads وموارد Homebrew.","hero.primary":"استكشف الفيرموير <b>↗</b>","hero.secondary":"اقرأ التوثيق","hero.open":"دخول مفتوح",
"stats.scope":"نطاق الفيرموير","stats.scopeNote":"نطاق مستهدف · التوافق يختلف","stats.modules":"أقسام المنصة","stats.modulesNote":"أقسام مستقلة","stats.access":"نظام الوصول","stats.accessNote":"دون حسابات أو اشتراكات","stats.status":"حالة المشروع","stats.statusNote":"موارد مجتمعية · تحقق قبل الاستخدام",
"sections.modules":"أقسام المنصة","sections.explore":"استكشف <em>النظام.</em>","sections.select":"اختر قسماً للمتابعة",
"cards.firmware":"مصفوفة الفيرموير","cards.firmwareDesc":"إصدارات النظام ومسارات المشاريع وملاحظات التحقق.","cards.webkit":"مختبر WebKit","cards.webkitDesc":"مشاريع البحث وبنية السلاسل والمصادر الأصلية.","cards.payloads":"خزنة البايلودز","cards.payloadsDesc":"مصادر البايلودز وبياناتها وفحص الملفات محلياً.","cards.homebrew":"هومبرو","cards.homebrewDesc":"تطبيقات المجتمع ومراجع التثبيت.","cards.tools":"الأدوات والمرافق","cards.toolsDesc":"دليل الأدوات المحلية وأدوات المطورين.","cards.docs":"التوثيق","cards.docsDesc":"الأدلة وملاحظات السلامة والحقوق وسياسات المشروع.",
"feature.title":"اعرف المصدر.<br><em>تحقق من الإصدار.</em>","feature.desc":"تفصل iXGAME بين الأكواد الأصلية للموقع والمشاريع الخارجية. يجب الحفاظ على ترخيص كل Payload خارجي وملاحظات توافقه.","feature.cta":"سياسة المشروع ↗"
}};
function setLanguage(lang) {
  const dict = translations[lang] || translations.en;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (dict[key]) el.innerHTML = dict[key];
  });
  const switcher = document.getElementById("lang-switch");
  if (switcher) switcher.textContent = lang === "ar" ? "EN" : "عربي";
  try { localStorage.setItem("ixgame-language", lang); } catch {}
}
let lang = "en";
try { lang = localStorage.getItem("ixgame-language") || "en"; } catch {}
setLanguage(lang);
document.getElementById("lang-switch")?.addEventListener("click", () => setLanguage(document.documentElement.lang === "ar" ? "en" : "ar"));
document.getElementById("mobile-toggle")?.addEventListener("click", () => document.getElementById("main-nav")?.classList.toggle("open"));
document.getElementById("year") && (document.getElementById("year").textContent = new Date().getFullYear());

const firmwareRows = [
["6.00–11.02","Lapse / NetCtrl","Owner-supplied route; exact per-build support must be checked in ntfonto upstream."],
["11.50","RawGame4","Upstream lists Lapse; hardware-tested."],
["12.00","RawGame4","Upstream lists Lapse; hardware-tested."],
["12.02","RawGame4","Upstream lists Lapse; hardware-tested."],
["12.50","RawGame4","Upstream lists Poops; hardware-tested."],
["12.52","RawGame4","Upstream lists Poops; hardware-tested."],
["13.00","RawGame4","Upstream lists Poops; hardware-tested."],
["13.02","Raw13G","Separate upstream project; exact entry documented."],
["13.04","Raw13G","Separate upstream project; exact entry documented."],
["13.50","Raw13G","Separate upstream project; exact entry documented."],
["13.52","Raw13G","Separate upstream project; exact entry documented."]
];
const fwBody = document.getElementById("firmware-rows");
if (fwBody) firmwareRows.forEach(row => {
 const tr = document.createElement("tr");
 row.forEach((v,i)=>{const td=document.createElement("td");td.textContent=v;if(i===2)td.className="muted";tr.append(td);});
 fwBody.append(tr);
});
document.getElementById("fw-search")?.addEventListener("input", e => {
 const q=e.target.value.toLowerCase();
 [...(fwBody?.rows||[])].forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(q));
});

const resourceData = [
["Lapse / NetCtrl — ntfonto","Upstream source directory","https://github.com/zecoxao/zecoxao.github.io/tree/main/ntfonto","Owner-supplied 6.00–11.02 route; inspect exact upstream files and notices."],
["RawGame4 repository","WebKit project · 11.50–13.00 route","https://github.com/rawgame4/rawgame4.github.io","Upstream README lists exact tested versions and AppCache hosting requirements."],
["RawGame4 official host","Official upstream host","https://rawgame4.github.io/","External host only; iXGAME does not proxy or execute it."],
["Raw13G repository","Separate WebKit project · 13.02–13.52 route","https://github.com/raw13g/raw13g.github.io","Check exact firmware entry, third-party component terms and release state."],
["Raw13G official host","Official upstream host","https://raw13g.github.io/","External host only; iXGAME does not proxy or execute it."],
["GoldHEN repository","Homebrew Enabler source and releases","https://github.com/GoldHEN/GoldHEN","Use official release notes; no GoldHEN binary is redistributed here."],
["Brewology PS4 Payload Catalog","Community payload catalog","https://store.brewology.com/ps4/payloads/","Compatibility and licenses vary by payload."],
["ConsoleMods PS4 Setup","Community documentation","https://consolemods.org/wiki/PS4:Recommended_Setup","Community-maintained setup guidance."]
];
const resources = document.getElementById("resource-list");
if(resources) resourceData.forEach(([name,tag,url,note])=>{
 const a=document.createElement("a");a.className="list-row";a.href=url;a.target="_blank";a.rel="noopener";
 const left=document.createElement("span");left.innerHTML=`<b>${name}</b><small>${tag}</small>`;
 const right=document.createElement("span");right.innerHTML=`<small>${note}</small><strong>OPEN ↗</strong>`;
 a.append(left,right);resources.append(a);
});
const fileInput=document.getElementById("payload-file"), inspect=document.getElementById("inspect-payload"), output=document.getElementById("inspection");
function bytes(n){return n<1024?n+" B":n<1048576?(n/1024).toFixed(1)+" KB":(n/1048576).toFixed(2)+" MB";}
inspect?.addEventListener("click",async()=>{
 const f=fileInput?.files?.[0];if(!f){output.textContent="Select a .bin or .elf file first.";return;}
 const ext=f.name.split(".").pop().toLowerCase();
 if(!["bin","elf"].includes(ext)){output.textContent="Unsupported file extension.";return;}
 if(!f.size||f.size>64*1024*1024){output.textContent="File is empty or exceeds the 64 MB limit.";return;}
 inspect.disabled=true;output.textContent="Inspecting locally…";
 try{
  const b=await f.arrayBuffer(),u=new Uint8Array(b);
  const elf=u.length>=4&&u[0]===0x7f&&u[1]===0x45&&u[2]===0x4c&&u[3]===0x46;
  const hash=await crypto.subtle.digest("SHA-256",b);
  const sha=[...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,"0")).join("");
  output.textContent=[`Name: ${f.name}`,`Size: ${bytes(f.size)}`,`Extension: .${ext}`,`ELF header: ${elf?"detected":"not detected"}`,`SHA-256: ${sha}`,"Compatibility: NOT verified","Execution / upload: not performed"].join("\\n");
 }catch(e){output.textContent="Inspection failed: "+e.message;}finally{inspect.disabled=false;}
});
