# Firmware and upstream integration notes

The firmware matrix is a routing reference, not an iXGAME exploit implementation or compatibility guarantee.
The ranges below are the project-owner's requested routing boundaries. The upstream repositories remain authoritative for exact firmware builds and test status.

| Firmware | Project route | Evidence / limitation |
|---|---|---|
| 6.00–11.02 | Lapse / NetCtrl (ntfonto) | Owner-supplied range. The ntfonto source directory could not be fetched into this build environment; verify exact versions and notices upstream. |
| 11.50–13.00 | RawGame4 | Its README lists 11.50, 12.00, 12.02, 12.50, 12.52 and 13.00 as hardware-tested. 10.01 is explicitly untested and is outside this requested route. |
| 13.02–13.52 | Raw13G | Keep separate from RawGame4. The repository tree includes its own browser, JS, offsets, patch and payload files; verify exact supported builds and third-party terms upstream. |

RawGame4 and Raw13G must not be mixed. Do not infer support for every intermediate firmware number merely from a range label.

## Integration status

- iXGAME retains its supplied static website, dashboard, navigation, CSS, JavaScript structure and original raven artwork.
- The firmware matrix now displays the requested project-family mapping and the discrete RawGame4 firmware versions explicitly documented upstream.
- Upstream projects are linked as references only. No exploit chain, kernel patch, offset table, payload binary or exploit launcher has been copied into this archive.
- No START / injection control existed in the supplied site. None has been fabricated; the site does not execute kernel exploits or security-bypass operations.
- The browser-local BIN/ELF inspector remains a file metadata/hash inspector only. It does not execute, upload, scan for malware or certify compatibility.

## Hosting notes

The supplied iXGAME site is a static website suitable for ordinary static hosting. It uses relative local paths and includes a GitHub Pages Actions workflow. The upstream RawGame4 README separately documents AppCache requirements (`text/cache-manifest`, and a non-cached manifest) for its own exploit host. Those requirements do not apply to this iXGAME reference portal because the upstream AppCache host has not been integrated.

## Verification boundary

No PS4 hardware was available. No exploit, payload, firmware compatibility or console-side behavior was tested. Browser-side validation of this static portal does not establish upstream exploit reliability.
