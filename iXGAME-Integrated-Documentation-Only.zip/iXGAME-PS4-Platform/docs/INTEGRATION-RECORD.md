# iXGAME integration record

## Original sources
- Lapse / NetCtrl (ntfonto): https://github.com/zecoxao/zecoxao.github.io/tree/main/ntfonto
- RawGame4: https://github.com/rawgame4/rawgame4.github.io
- RawGame4 host: https://rawgame4.github.io/
- Raw13G: https://github.com/raw13g/raw13g.github.io
- Raw13G host: https://raw13g.github.io/
- GoldHEN: https://github.com/GoldHEN/GoldHEN

## Scope delivered
This archive retains the supplied iXGAME frontend and makes only small documentation, source-index and firmware-matrix changes. Upstream repositories are linked, not mirrored. The exploit code, kernel patches, offsets and executable payload binaries are intentionally not redistributed or wired into this portal. The build environment could not fetch GitHub release/archive bytes directly, so no upstream source files are claimed as locally retrieved.

## Firmware routing
- 6.00–11.02 → Lapse / NetCtrl (ntfonto; owner-supplied mapping)
- 11.50–13.00 → RawGame4
- 13.02–13.52 → Raw13G

Use exact upstream firmware entries rather than assuming every version in a range is supported. See `docs/FIRMWARE-NOTES.md`.

## Licensing
- iXGAME frontend: see the root `LICENSE` (MIT).
- RawGame4: repository states its port work is MIT; bundled SLOPKIT primitives, GoldHEN and kernel patch blobs retain separate terms. No such code or binaries are included.
- Raw13G: repository's MIT notice applies to code authored by raw13g; its notice expressly excludes third-party primitives, payload binaries and kernel patch blobs. None are included.
- ntfonto: license/notice was not independently verified in this build; review the upstream directory before copying or redistributing files.
- GoldHEN: no GoldHEN binary or source is included. Use the official release page and its release-specific terms.

## Developer
Instagram: @X_C_p1

## Hosting
Host the contents of `iXGAME-PS4-Platform/` as a static site. GitHub Pages workflow is retained. The AppCache/MIME/cache rules in RawGame4's README apply to RawGame4's own host, not to this iXGAME portal.

## Known limitations
No START / injection button was present in the supplied project. No fake launcher or success message was added. No kernel-exploit execution or security-bypass functionality is implemented. No PS4 hardware testing was performed.
