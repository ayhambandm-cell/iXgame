# iXGAME — PS4 Multi-Firmware Host

An independent static PS4 research and resource portal. The supplied frontend, navigation, styles, scripts, raven artwork and GitHub Pages workflow are retained.

## Included
- Existing dashboard and page structure.
- Searchable firmware route matrix.
- Upstream source directory and official-host references.
- Browser-local BIN/ELF metadata and SHA-256 inspector.
- Developer attribution: Instagram **@X_C_p1**.

## Firmware routing
- 6.00–11.02: Lapse / NetCtrl (ntfonto; owner-supplied range).
- 11.50–13.00: RawGame4.
- 13.02–13.52: Raw13G.

See `docs/FIRMWARE-NOTES.md` for exact upstream version notes and limitations.

## Important scope
This is a reference portal, not a jailbreak engine. No upstream exploit implementation, kernel patch, offset table or executable payload is bundled or executed. No START/injection control existed in the supplied project, so none has been fabricated. No PS4 hardware test was performed.

## Sources and licensing
See `docs/INTEGRATION-RECORD.md`. Original third-party notices and licensing conditions must be checked at their source before redistribution. The root `LICENSE` applies to the supplied iXGAME project files only.

## Deploy
Upload the contents of this directory to a static host or use the included GitHub Pages workflow. The RawGame4 AppCache/MIME requirements apply only if separately hosting that upstream project, not this iXGAME portal.
