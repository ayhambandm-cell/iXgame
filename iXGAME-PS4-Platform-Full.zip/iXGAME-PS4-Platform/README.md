# iXGAME — Raven Protocol

Independent PS4 WebKit, firmware research, payload source index and homebrew resource portal.

## Features
- Dark Gaming + Hacker + Cyberpunk visual system.
- Original SVG raven emblem with CSS animation.
- Arabic / English language switch with RTL support.
- Separate pages for firmware, WebKit, payloads, homebrew, tools and documentation.
- Searchable firmware matrix.
- Browser-local BIN / ELF inspector (file size, ELF magic and SHA-256).
- GitHub Pages workflow.

## Deploy to GitHub Pages
1. Create a repository named `ixgame-ps4-platform` (or any name).
2. Upload the contents of this directory to the repository root.
3. In GitHub, open **Settings → Pages**.
4. Set the source to **GitHub Actions**.
5. Push to the default branch. The included workflow deploys the static site.

## Important limits
This repository is a working static resource portal, not a jailbreak engine. It does not contain WebKit exploit code, kernel patches, exploit offsets, or executable payload binaries. The Payload Inspector does not execute, upload, validate safety or certify compatibility.

## Ownership
The original iXGAME frontend, CSS, JavaScript, page structure and raven SVG are provided under the repository LICENSE. Third-party names, repositories and payloads remain subject to their respective owners' terms. No affiliation with Sony or PlayStation is implied.
